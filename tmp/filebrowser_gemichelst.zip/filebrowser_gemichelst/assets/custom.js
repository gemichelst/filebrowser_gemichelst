const debug = true;
var curWinWidth = $(window).width(),
    curWinHeight = $(window).height();



$(document).ready(function() {


console.log('filebrowser-geMichelst v1');






});
